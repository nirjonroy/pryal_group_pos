<?php

namespace App\Model\Backend\Admin\User;

use Illuminate\Database\Eloquent\Model;

class User_role extends Model
{
    //
}

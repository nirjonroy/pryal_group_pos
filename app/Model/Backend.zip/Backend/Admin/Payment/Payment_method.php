<?php

namespace App\Model\Backend\Admin\Payment;

use Illuminate\Database\Eloquent\Model;

class Payment_method extends Model
{
    //
}

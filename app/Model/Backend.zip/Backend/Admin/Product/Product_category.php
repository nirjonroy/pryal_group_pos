<?php

namespace App\Model\Backend\Admin\Product;

use Illuminate\Database\Eloquent\Model;

class Product_category extends Model
{
    //
}
